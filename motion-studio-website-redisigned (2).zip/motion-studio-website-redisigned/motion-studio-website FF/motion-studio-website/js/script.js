// Motion Studio - script
// Form validation and interactive features are added in Part 3.

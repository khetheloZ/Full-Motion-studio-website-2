# Motion Studio Website

## Student Information
- **Name:** Khethelo Zondi
- **Student Number:** ST10530976
- **Module:** Web Development (Introduction) - WEDE5020
- **Institution:** The Independent Institute of Education (IIE) - Rosebank College

## Project Overview
Motion Studio is a family-run photography studio offering studio hire, themed
backdrops, and full photoshoot packages (studio hire, studio hire with lights,
venue hire, studio hire with in-house photographer, podcast set, maternity
shoots, and graduation shoots). This project builds a five-page website for
the studio to replace its current reliance on Instagram, Facebook, and
TikTok alone.

## Website Goals and Objectives
- Present all studio packages and pricing clearly in one place.
- Allow visitors to submit a booking enquiry online.
- Build a more professional, credible online presence for the studio.
- KPI: number of enquiry form submissions and growth in website visits.

## Key Features and Functionality
- Home page with hero section and call to action.
- About page with studio history, mission, and team.
- Services page listing all packages.
- Enquiry page with a booking enquiry form.
- Contact page with studio details, an embedded map, and a contact form.

## Timeline and Milestones
| Phase  | Focus                                              | Target Period |
|--------|-----------------------------------------------------|----------------|
| Part 1 | Planning, content research, HTML structure          | Weeks 1-3      |
| Part 2 | CSS styling, responsive design                      | Weeks 4-6      |
| Part 3 | JavaScript, SEO, testing and final submission       | Weeks 7-9      |

## Contact Details
- **Address:** 39 Station Drive, Durban
- **Phone:** 075 400 7473
- **Email:** bookings@motionstudioza.com

## Part 1 Details
Part 1 covers the foundational HTML structure of the website:
- Five linked pages: `index.html`, `about.html`, `services.html`,
  `enquiry.html`, `contact.html`.
- Semantic HTML5 elements (`header`, `nav`, `main`, `section`, `footer`).
- A working navigation menu linking all pages.
- `css/styles.css` and `js/script.js` created as placeholders, styled out in Part 2
  below; JS interactivity still to follow in Part 3.

## Part 2 Details
Part 2 covers the visual design and responsive layout of the site:
- External stylesheet (`css/styles.css`) linked from all five pages, built around
  a single set of CSS custom properties (colour, type, spacing) rather than
  repeated values, so the whole site can be re-themed from one place.
- Colour palette: charcoal ink, off-white paper, and a warm brass gold accent,
  matching the studio's proposed colour scheme.
- Typography: Archivo (headings) and Work Sans (body), loaded from Google Fonts,
  with a fluid type scale using `clamp()` for the hero heading.
- Desktop layout built with Flexbox (header/nav, footer, enquiry form columns)
  and CSS Grid (hero image collage using `grid-template-areas`, services grid,
  gallery grid, team grid), keeping selectors to a minimum by relying on the
  cascade from the shared design tokens.
- Visual styling: hover/focus/active states on all links and buttons, a visible
  gold `:focus-visible` outline for keyboard users, and `prefers-reduced-motion`
  support.
- Responsive design: mobile-first base styles with breakpoints at 600px
  (tablet) and 1024px (desktop), using relative units (`rem`, `em`, `vw`, `%`)
  throughout instead of fixed pixel values.
- Responsive images: generated 480w and 828w versions of each studio photo and
  added `srcset`/`sizes` to the hero, gallery, and package images, plus a
  `<picture>` element with breakpoint-based `<source>`s on the About page studio
  photo, so smaller screens download a smaller file.
- Tested in-browser at mobile, tablet, and desktop widths using Chrome DevTools'
  device toolbar.

## Testing & Responsive Evidence
The site was tested in Chrome DevTools' device toolbar at mobile, tablet, and
desktop widths, confirming the mobile-first breakpoints at 600px and 1024px
behave as intended (single-column mobile layout, two-column tablet layout with
the hero and gallery grids expanding, and the full multi-column desktop layout
with the hero collage and side-by-side sections). Screenshots of the home page
at each width:

**Mobile (390px)**
![Home page on mobile](images/screenshots/index-mobile.jpg)

**Tablet (768px)**
![Home page on tablet](images/screenshots/index-tablet.jpg)

**Desktop (1440px)**
![Home page on desktop](images/screenshots/index-desktop.jpg)

## Sitemap
```
Home (index.html)
├── About (about.html)
├── Services (services.html)
├── Enquiry (enquiry.html)
└── Contact (contact.html)
```

## Changelog
- **Part 2 (complete):** Visual design and bug-fix pass across the whole site.
  Fixed several photos (hero portrait, "What Makes Motion Studio Different",
  the founder portrait, the Services and Enquiry page images, and three
  gallery photos) that were cropping people's faces out under
  `object-fit: cover` — added a per-photo `object-position` so every portrait
  stays properly framed wherever it's reused across pages. Fixed a layout bug
  where `<picture>` elements (inline by default) were silently breaking
  `width: 100%` on the About page's studio photo. Fixed a CSS specificity bug
  where the odd/even alternating section-background rule could override the
  dark CTA band's own background depending on how many sections came before
  it on a given page (visible on the Contact page, where the closing CTA text
  was rendering almost invisible). Fixed page-heading paragraphs
  (Services/Enquiry) being auto-centred instead of sitting flush under the
  heading, and removed the old `align="center"/"left"` HTML attributes on
  Services that had been worked around it. Fixed the photo gallery grid
  leaving empty cells at tablet/desktop — the implicit grid rows were sized
  to the tall 2×2 feature photo while the smaller photos kept a fixed height,
  leaving dead space; switched to a uniform `grid-auto-rows` with images at
  `height: 100%` so every cell fills exactly, and added `grid-auto-flow:
  dense` alongside a subtle hover zoom. Rebuilt the "Meet the Team" section
  (previously one small tile with a large empty gap beside it) into a proper
  founder-spotlight layout with the photo beside the bio. Gave the About page
  banner photo and "What Makes Motion Studio Different" photo more presence
  (taller, with a soft shadow) now that they're correctly framed, and added a
  second photo to the Contact page so it isn't the only page without one.
  Added subtle shadows (header, buttons, images) for depth consistent with
  the site's existing flat/editorial look, and a hover-lift on buttons.
- **Part 2 (complete):** Added a "Testing & Responsive Evidence" section to this
  README with mobile, tablet, and desktop screenshots of the home page
  (`images/screenshots/`), confirming the breakpoints behave as intended.
- **Part 2 (complete):** Built out `css/styles.css` with a full design system —
  colour and type custom properties, base/reset styles, typography scale,
  Flexbox/Grid desktop layout (including `grid-template-areas` for the hero
  collage), hover/focus/active states, and mobile-first responsive breakpoints
  at 600px and 1024px. Added `srcset`/`sizes` to hero, gallery, and package
  images and a `<picture>` element on the About page, with generated 480w/828w
  image variants in `images/`. Added Google Fonts (Archivo, Work Sans)
  preconnect links to the `<head>` of all five pages. No corrections were
  required from Part 1 feedback at the time of this submission; the HTML
  structure carries over unchanged aside from wrapping the homepage hero text
  in a `<div class="hero-text">` so it could be targeted as a single CSS Grid
  area.
- **Part 1 (complete):** All five HTML pages finalised with semantic structure,
  working navigation, Motion Studio images, gallery, service descriptions with
  supplied pricing, enquiry form fields (including preferred time and number of
  people), contact details, embedded map, and HTML comments. CSS and JS left as
  placeholders for Parts 2–3.
- **Part 1:** Initial project setup, folder structure, and HTML pages created
  with navigation and base content.

## Images
All images in `images/` are original Motion Studio photography supplied for this
project. Files used:
- `hero-wall.png` — homepage hero and gallery
- `hero-backdrops.png` — homepage hero, services page, and gallery
- `logo.png` — site header logo
- `studio-equipment.png` — about page
- `gallery-celebration.png` — homepage gallery
- `team-member.png` — about page team section

For Part 2, each photo above (aside from the logo) was resized into `-480w.jpg`
and `-828w.jpg` variants for use in `srcset`/`sizes` and the About page
`<picture>` element, so mobile devices load a smaller file.

## References
Sources consulted while researching and planning this website:

Afrihost (n.d.) *Web hosting packages*. Available at: https://www.afrihost.com/ (Accessed: 6 August 2026).

Digital Silk (2024) *Top 50 small business website statistics*. Available at: https://www.digitalsilk.com/web-design/web-trends/small-business-website-statistics/ (Accessed: 6 August 2026).

Mozilla Developer Network (n.d.) *Mobile first - MDN Web Docs Glossary*. Available at: https://developer.mozilla.org/en-US/docs/Glossary/Mobile_First (Accessed: 6 August 2026).

Google Fonts (n.d.) *Archivo* and *Work Sans*. Available at: https://fonts.google.com/ (Accessed: 11 September 2026).

Motion Studio images:

Original set:
- hero-wall.png       — studio feature wall (gallery)
- hero-backdrops.png  — backdrop rolls (services page heading, gallery)
- logo.png            — Motion Studioz logo (header on all pages)
- studio-equipment.png — studio lighting setup (gallery)
- gallery-celebration.png — client shoot (homepage gallery)
- team-member.png     — founder/owner portrait (about page)

Added client/editorial set (each has a matching -480w.jpg and -828w.jpg for
responsive srcset):
- portrait-tan-suit.jpg          — home page hero (left)
- editorial-navy-corset.jpg      — services page main image + gallery
- maternity-white-gown.jpg       — gallery
- editorial-yellow-gown.jpg      — gallery
- editorial-feather-white.jpg    — about page (what makes us different) + gallery
- maternity-pink-top.jpg         — gallery
- editorial-fringe-colour.jpg    — enquiry page image + gallery
- editorial-construction-concept.jpg — gallery
- client-naledi-art.jpg          — gallery (client portfolio work)
- studio-lighting-setup.jpg      — about page (top studio image) + gallery

All images are original Motion Studio photography supplied for this project.
